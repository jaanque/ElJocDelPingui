package vista;

public class pantallaPartida {

}
