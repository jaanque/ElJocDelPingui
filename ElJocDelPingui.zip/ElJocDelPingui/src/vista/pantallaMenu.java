package vista;

public class pantallaMenu {

}
