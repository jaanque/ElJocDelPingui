package modelo;

public class gestorPartidas {
	private String urlBBDD;
	private String username;
	private String password;

}
