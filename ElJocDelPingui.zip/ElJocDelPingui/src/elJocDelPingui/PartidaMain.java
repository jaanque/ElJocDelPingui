package elJocDelPingui;
import java.util.Scanner;
import java.util.ArrayList;



public class PartidaMain {
	 public static void main(String[] args) {

	 }
}