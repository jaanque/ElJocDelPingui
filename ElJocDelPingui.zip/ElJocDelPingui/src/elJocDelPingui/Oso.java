package elJocDelPingui;

public class Oso {

}
