package elJocDelPingui;

public class CasillaInterrogante {

}
