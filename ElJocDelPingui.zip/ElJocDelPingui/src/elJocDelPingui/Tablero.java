package elJocDelPingui;

public class Tablero {

}
