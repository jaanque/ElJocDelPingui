package elJocDelPingui;

public class Trineo {
	

}
