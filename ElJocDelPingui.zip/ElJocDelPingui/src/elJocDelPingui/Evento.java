package elJocDelPingui;

public class Evento {

}
