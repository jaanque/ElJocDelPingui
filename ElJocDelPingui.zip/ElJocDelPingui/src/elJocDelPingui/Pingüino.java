package elJocDelPingui;

public class Pingüino {

}
