package elJocDelPingui;

public class DadoEspecial {

}
