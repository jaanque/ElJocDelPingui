package elJocDelPingui;

public class Dado {

}
